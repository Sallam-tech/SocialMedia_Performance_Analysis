
# Social Media Performance Analysis

This project analyzes Instagram post performance using a simulated dataset based on Internee.pk's account.

## Dataset Columns
- Date
- Post Type (Image, Reel, etc.)
- Caption
- Likes, Comments, Shares
- Reach & Impressions
- Calculated Engagement Rate

## Objective
To identify top-performing posts, calculate engagement rate, and visualize trends to guide content strategies.

## Technologies Used
- Python (Pandas, Matplotlib, Seaborn)
- Jupyter Notebook

## How to Use
1. Open `SocialMedia_Performance_Analysis.ipynb` in Jupyter Notebook.
2. Run each cell to view analysis and visualizations.
3. The dataset is stored in `social_media_data.csv`.

## Visualization
![Engagement Rate Over Time](engagement_rate_plot.png)
